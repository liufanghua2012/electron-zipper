The xunit.extensions package has been retired.

Some of the classes contained in extensions are now part of the core
framework, and some are now part of the samples. For more information,
please visit:

http://xunit.github.io/docs/upgrade-extensions.html
