﻿#region Header
// Copyright (c) 2013-2015 Hans Wolff
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.
#endregion

using System;
using System.IO;
using System.Text;
using System.Threading;
using Simple.MailServer.Mime;

namespace Simple.MailServer.Tests.Helpers
{
    static class TestHelpers
    {
        private static int _testPort = new Random(Environment.TickCount).Next(10000, 60000);

        public static int GetTestPort()
        {
            return Interlocked.Increment(ref _testPort);
        }

        public static MemoryStream TextToStream(string text)
        {
            return new MemoryStream(Encoding.Default.GetBytes(text));
        }

        public static string ReadMemoryStreamIntoString(MemoryStream mem)
        {
            return Encoding.Default.GetString(mem.ToArray());
        }

        public static StringReaderStream CreateStringReaderStreamFromText(string text, int bufferSize = 4096)
        {
            var textAsBytes = Encoding.ASCII.GetBytes(text ?? "");
            var memoryStream = new MemoryStream(textAsBytes);
            return new StringReaderStream(memoryStream, bufferSize);
        }

    }
}
